##QGIS plugin for splitting polygons into equal area parts

The plugin takes the polygons of the active QGIS layer and slices them up into equal parts by horizontal, vertical, or alternating lines.

